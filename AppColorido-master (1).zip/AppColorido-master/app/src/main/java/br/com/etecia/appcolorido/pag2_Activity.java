package br.com.etecia.appcolorido;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class pag2_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pag2_layout);
    }
}
